<div class='section sponsors'>
    <div class="sponsor_container">
        <h2>Sponsors</h2>
        <hr />
        <div class='blk-3'>
            <a href="http://sigchi.org">
                <img src='<?php echo BASE_PATH; ?>/lib/img/sponsors/logo_sigchi.gif' alt="Sig Chi" />
            </a>
        </div><div class='blk-3'>
            <a href="http://acm.org">
                <img src="<?php echo BASE_PATH; ?>/lib/img/sponsors/logo-acm.gif" alt="ACM" />
            </a>
        </div><div class='blk-3'>
            <a href="http://siggraph.org">
                <img src='<?php echo BASE_PATH; ?>/lib/img/sponsors/logo_siggraph.gif.jpg' alt='SIGGRAPH' />
            </a>
        </div>
    </div>
    <div class="sponsor_container">
        <h2>Platinum</h2>
        <hr />
        <div class='blk-3'>
            <a href="http://autodesk.com">
                <img src='<?php echo BASE_PATH; ?>/lib/img/sponsors/Autodesk.png' alt='Autodesk' />
            </a>
        </div>
    </div>

    <div class="sponsor_container">
        <h2>Gold</h2>
        <hr />

    </div>

    <div class="sponsor_container">
        <h2>Silver</h2>
        <hr />

    </div>
    <div class="sponsor_container">
        <h2>Bronze</h2>
        <hr />
      
    </div>
    <div class="sponsor_container">
        <h2>Friends of UIST</h2>
        <hr />
 
    </div>
</div>