<div class="section about">
    <div class="blk-1">

        <h2>About</h2><br />
        <p clas="about">
            The ACM Symposium on User Interface Software and Technology (UIST) is the premier forum for innovations in human-computer interfaces. Sponsored by ACM special interest groups on computer-human interaction (SIGCHI) and computer graphics (SIGGRAPH), UIST brings together people from diverse areas including graphical & web user interfaces, tangible & ubiquitous computing, virtual & augmented reality, multimedia, new input & output devices, and CSCW. The intimate size and intensive program make UIST an ideal opportunity to exchange research results and ideas. Join us in Charlotte!
        </p><br/>

        <h2>Some inspirational work from UIST 2014!</h2>
        <iframe class='video about' style="display: block; margin: 40px auto; width: 100%; height: 512px;"src="//www.youtube.com/embed/Ko9aTztcfNE" frameborder="0" allowfullscreen></iframe>

        
        </div>

</div>