<script type="text/javascript" src="./lib/js/updates.js"></script>

<script type="text/javascript">
    Updates.init("./lib/updates.json","#updateTemplate", "#updateList", "deadline");
</script>

<div class="section updates">
    <div class="blk-1">
    </div><div id="updateContainer" class="blk-1"><h2>Dates</h2><br />
        <div id="updateList">
            <!-- Updates get generated here -->
        </div>
    </div>
</div>

<!-- Template for generating updates -->
<div class="update" id="updateTemplate" style="display: none;">
    <span class="date"></span>
    <p class="text"></p>
</div>