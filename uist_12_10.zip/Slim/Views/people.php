<div class="section people">
    

  <div class="speakers">
        <h2>General Chair</h2><br />
        <div class="blk-3" style="text-align: center; margin-top: 20px;">
            <figure>
                <a href="http://hci.uncc.edu/~clatulip/clwp/">
                    <img class="round" src="<?php echo BASE_PATH; ?>/lib/img/people/clatulipe.jpg" alt="Celine Latulipe" />

                <figcaption>
                    <span style="font-size: 1.4em;">
                        Celine Latulipe</a>
                    </span><br />
                    <em>UNC at Charlotte</em>

                </figcaption>
                </a>
            </figure>
        </div>

  </div>
  <div class="speakers">
    <h2>Program Committee Co-Chairs</h2> 
        </div><div class="blk-3" style="text-align: center; margin-top: 20px;">

           <figure>
                <a href="http://bjoern.org/">
                    <img class="round" src="<?php echo BASE_PATH; ?>/lib/img/people/bhartmann.jpg" alt="Bjoern Hartmann" />

                <figcaption>
                    <span style="font-size: 1.4em;">
                        Bjoern Hartmann</a>
                    </span><br />
                    <em>UC Berkeley</em>

                </figcaption>
                </a>
            </figure>
           
        </div><div class="blk-3" style="text-align: center; margin-top: 20px;">
            <figure>
              <a href="http://www.tovigrossman.com/">
                <img class="round" src="<?php echo BASE_PATH; ?>/lib/img/people/tgrossman.jpg" alt="Tovi Grossman" />
                <figcaption>
                    <span style="font-size: 1.4em;">Tovi Grossman</a></span><br />
                    <em>Autodesk Research</em>
                </figcaption>
              
            </figure>
        </div>

  <div class="speakers">
        <h2>Sponsorship Chair</h2><br />
        <div class="blk-3" style="text-align: center; margin-top: 20px;">
            <figure>
                <a href="http://www.jeffreynichols.com/">
                <img class="round" src="<?php echo BASE_PATH; ?>/lib/img/people/jeff.jpg" alt="Jeff Nichols" />

                <figcaption>
                    <span style="font-size: 1.4em;">
                        Jeff Nichols</a>
                    </span><br />
                    <em>Google</em>

                </figcaption>
                </a>
            </figure>
        </div>

  </div>

  <div class="speakers">
        <h2>Treasurer and Local Arrangements</h2><br />
        <div class="blk-3" style="text-align: center; margin-top: 20px;">
            <figure>
                <a href="http://coitweb.uncc.edu/~davils/">
                    <img class="round" src="<?php echo BASE_PATH; ?>/lib/img/people/dwilson.bmp" alt="David Wilson" />

                <figcaption>
                    <span style="font-size: 1.4em;">
                        David Wilson</a>
                    </span><br />
                    <em>UNC at Charlotte</em>

                </figcaption>
               </a>
            </figure>
        </div>
</div>
  <div class="speakers">
        <h2>Web and Social Media Chair</h2><br />
        <div class="blk-3" style="text-align: center; margin-top: 20px;">
            <figure>
                <a href="http://stephenmacneil.net">
                    <img class="round" src="<?php echo BASE_PATH; ?>/lib/img/people/smacneil.jpeg" alt="Stephen MacNeil" />

                <figcaption>
                    <span style="font-size: 1.4em;">
                        Stephen MacNeil</a>
                    </span><br />
                    <em>UNC at Charlotte</em>

                </figcaption>
                </a>
            </figure>
        </div>
</div>
</div>

