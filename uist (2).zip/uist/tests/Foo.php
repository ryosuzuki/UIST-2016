<?php
class Foo
{
    public function __construct()
    {
    }
}
