<?php

    /* Our routes go here. You can use the primary REST verbs (GET, POST, PUSH, DELETE)
       "category" is the menu anchor that should be underlined. Make sure it matches */
    $app->get('/', function () use ($app) {
        $app->redirect('./about');
    });

    $app->get('/about', function () use ($app) {
        $app->render('Layouts/main.php', array("app" => $app, "view" => "home.php", "category" => "about"));
    });

    $app->get('/updates', function () use ($app) {
        $app->render('Layouts/main.php', array("app" => $app, "view" => "updates.php", "category" => "updates"));
    });

    $app->get('/people', function () use ($app) {
        $app->render('Layouts/main.php', array("app" => $app, "view" => "people.php", "category" => "people"));
    });

    $app->get('/dates', function () use ($app) {
        $app->render('Layouts/main.php', array("app" => $app, "view" => "dates.php", "category" => "dates"));
    });

    $app->get('/people/:name', function ($id) use ($app) {
        $app->render('Layouts/main.php', array("app" => $app, "view" => "Bios/$id.php",  "category" => "people"));
    });