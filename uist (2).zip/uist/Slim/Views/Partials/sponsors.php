<div class='section sponsors'>
    <div class="sponsor_container">
        <h2>Sponsors</h2>
        <hr />
        <div class='blk-3'>
            <a href="http://sigchi.org">
                <img src='<?php echo BASE_PATH; ?>/lib/img/sponsors/logo_sigchi.gif' alt="Sig Chi" />
            </a>
        </div><div class='blk-3'>
            <a href="http://acm.org">
                <img src="<?php echo BASE_PATH; ?>/lib/img/sponsors/logo-acm.gif" alt="ACM" />
            </a>
        </div><div class='blk-3'>
            <a href="http://siggraph.org">
                <img src='<?php echo BASE_PATH; ?>/lib/img/sponsors/logo_siggraph.gif.jpg' alt='SIGGRAPH' />
            </a>
        </div>
    </div>
    <div class="sponsor_container">
        <h2>Platinum</h2>
        <hr />
        <div class='blk-3'>
            <a href="http://autodesk.com">
                <img src='<?php echo BASE_PATH; ?>/lib/img/sponsors/Autodesk.png' alt='Autodesk' />
            </a>
        </div><div class='blk-3'>
            <a href="http://microsoft.com">
                <img src='<?php echo BASE_PATH; ?>/lib/img/sponsors/MSFT_logo_rgb_C-Gray_D.jpg' alt='Microsoft' />
            </a>
        </div>
    </div>

    <div class="sponsor_container">
        <h2>Gold</h2>
        <hr />
        <div class='blk-3'>
            <a href="http://marvell.com">
                <img src='<?php echo BASE_PATH; ?>/lib/img/sponsors/Marvell.JPG' alt='Marvell' />
            </a>
        </div><div class='blk-3'>
            <a href="http://synaptics.com">
                <img src='<?php echo BASE_PATH; ?>/lib/img/sponsors/Synaptics.png' alt='Synaptics' />
            </a>
        </div>
    </div>

    <div class="sponsor_container">
        <h2>Silver</h2>
        <hr />
        <div class='blk-3'>
            <a href="http://grand-nce.ca">
                <img src='<?php echo BASE_PATH; ?>/lib/img/sponsors/GRAND_logo.png' alt='Grand' />
            </a>
        </div><div class='blk-3'>
            <a href="http://wacom.com">
                <img src='<?php echo BASE_PATH; ?>/lib/img/sponsors/wacom_logo.jpg' alt='Wacom' />
            </a>
        </div><div class='blk-3'>
            <a href="http://adobe.com">
                <img src='<?php echo BASE_PATH; ?>/lib/img/sponsors/Adobe-Logo.jpg' alt='Adobe' />
            </a>
        </div>
    </div>
    <div class="sponsor_container">
        <h2>Bronze</h2>
        <hr />
        <div class='blk-3'>
            <a href="http://fxpal.com">
                <img src='<?php echo BASE_PATH; ?>/lib/img/sponsors/fxpal_sm.png' alt='Fxpal' />
            </a>
        </div><div class='blk-3'>
            <a href="http://google.com">
                <img src='<?php echo BASE_PATH; ?>/lib/img/sponsors/google_small.jpg' alt='Google' />
            </a>
        </div><div class='blk-3'>
            <a href="http://research.ibm.com">
                <img src='<?php echo BASE_PATH; ?>/lib/img/sponsors/IBM_Research.jpg' alt='IBM Research' />
            </a>
        </div>
        <div class='blk-3'>
            <a href="http://tactuallabs.com">
                <img src='<?php echo BASE_PATH; ?>/lib/img/sponsors/tactual-small.jpg' alt='Tactual' />
            </a>
        </div><div class='blk-3'>
            <a href="http://yahoo.com">
                <img src='<?php echo BASE_PATH; ?>/lib/img/sponsors/yahoo.png' alt='Yahoo Labs' width=262.5 height=50/>
            </a>
        </div><div class='blk-3'>
            <a href="http://manoa.hawaii.edu/hichi/">
                <img src='<?php echo BASE_PATH; ?>/lib/img/sponsors/HICHILogo.jpg' alt='HICHI' width=164.5 height=75/>
            </a>
        </div>
    </div>
    <div class="sponsor_container">
        <h2>Friends of UIST</h2>
        <hr />
        <div class='blk-3'>
            <a href="http://disneyresearch.com">
                <img src='<?php echo BASE_PATH; ?>/lib/img/sponsors/disney.jpg' alt='Disney Research'/>
            </a>
        </div>
    </div>
</div>