<div class='banner'>
    <div class='cover'>
        <div class='blk-1'>
            <span>28th ACM User Interface Software and Technology Symposium</span>
            <span style='font-size: 1.4em;'>Charlotte, NC<br />October, 2015</span>
        </div>
    </div>
</div>