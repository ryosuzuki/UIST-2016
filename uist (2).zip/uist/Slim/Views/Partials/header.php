<div class='header'>
    <nav class='main'>
        <ul id="mainNav">
            <li>
                <a href="<?php echo BASE_PATH; ?>/about"><i class="fa fa-question-circle"></i>About</a>
            </li>
            <li>
                <a href="<?php echo BASE_PATH; ?>/updates"><i class="fa fa-quote-left"></i>Updates</a>
            </li>
            <li class='dropdown'>
                <a href="#" onclick="return false"><i class="fa fa-cog"></i>Details<span style="font-size: 0.6em; margin-left: 5px;">▼</span></a>
                <ul>
                    <li class="nav regular">
                        <a href="#">Test 1</a>
                    </li>
                    <li class="nav regular">
                        <a href="#">Test 2</a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="<?php echo BASE_PATH; ?>/people"><i class="fa fa-users"></i>People</a></li>
            <li>
                <a href="<?php echo BASE_PATH; ?>/dates"><i class="fa fa-calendar"></i>Dates</a></li>
            <li>
                <a href="<?php echo BASE_PATH; ?>/archive"><i class="fa fa-archive"></i>Archive</a>
            </li>
        </ul>
        <button type="button" class="toggle">
            <i class="fa fa-bars fa-4x"></i>
        </button>
    </nav>
</div>

