<div class="section about">
    <div class="blk-1">

        <h2>About</h2><br />
        <p clas="about">
            The ACM Symposium on User Interface Software and Technology (UIST) is the premier forum for innovations in human-computer interfaces. Sponsored by ACM special interest groups on computer-human interaction (SIGCHI) and computer graphics (SIGGRAPH), UIST brings together people from diverse areas including graphical & web user interfaces, tangible & ubiquitous computing, virtual & augmented reality, multimedia, new input & output devices, and CSCW. The intimate size and intensive program make UIST an ideal opportunity to exchange research results and ideas.
            This year we'll be co-located with ACM Spatial User Interaction Symposium (October 4-5, 2014).
            Join us in Waikiki!
        </p><br/>

        <iframe class='video about' style="display: block; margin: 40px auto; width: 100%; height: 512px;"src="//www.youtube.com/embed/Ko9aTztcfNE" frameborder="0" allowfullscreen></iframe>

        <div class="speakers">
            <h2>Keynote Speakers</h2><br />
            <div class="blk-3" style="text-align: center; margin-top: 20px;">
                <figure>
                    <img class="round" src="./lib/img/people/markbolas.jpg" alt="Mark Bolas" />
                    <figcaption>
                        <span style="font-size: 1.4em;">Mark Bolas</span><br />
                    </figcaption>
                </figure>
            </div><div class="blk-3" style="text-align: center; margin-top: 20px;">
                <figure>
                    <img class="round" src="./lib/img/people/bretvictor.png" alt="Mark Bolas" />
                    <figcaption>
                        <span style="font-size: 1.4em;">Bret Victor</span><br />
                    </figcaption>
                </figure>
            </div>
        </div>

        <h2>Program Chairs</h2><br />
        <div class="chairs">
            <div class="blk-3" style="text-align: center; margin-top: 20px;">
                <figure>
                    <img class="round" src="./lib/img/people/Hrvoje_Benko.jpg" alt="Hrvoje Benko" />
                    <figcaption>
                        <span style="font-size: 1.4em;">Hrvoje Benko</span><br />
                    </figcaption>
                </figure>
            </div><div class="blk-3" style="text-align: center; margin-top: 20px;">
                <figure>
                    <img class="round" src="./lib/img/people/daniel-wigdor.png" alt="Daniel Wigdor" />
                    <figcaption>
                        <span style="font-size: 1.4em;">Daniel Wigdor</span><br />
                    </figcaption>
                </figure>
            </div><div class="blk-3" style="text-align: center; margin-top: 20px;">
            <figure>
                <img class="round" src="./lib/img/people/photo.jpg" alt="Mira Dontcheva" />
                <figcaption>
                    <span style="font-size: 1.4em;">Mira Dontcheva</span><br />
                </figcaption>
            </figure>
        </div>
        </div>

    </div>
</div>