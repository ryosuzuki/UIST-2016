<div class="section people">
    <div class="speakers">
        <h2>Keynote Speakers</h2><br />
        <div class="blk-3" style="text-align: center; margin-top: 20px;">
            <figure>
                <a href="people/mark_bolas">
                    <img class="round" src="<?php echo BASE_PATH; ?>/lib/img/people/markbolas.jpg" alt="Mark Bolas" />

                <figcaption>
                    <span style="font-size: 1.4em;">
                        Mark Bolas</a>
                    </span><br />
                </figcaption>
                </a>
            </figure>
        </div><div class="blk-3" style="text-align: center; margin-top: 20px;">
            <figure>
                <img class="round" src="<?php echo BASE_PATH; ?>/lib/img/people/bretvictor.png" alt="Mark Bolas" />
                <figcaption>
                    <span style="font-size: 1.4em;">Bret Victor</span><br />
                </figcaption>
            </figure>
        </div>
    </div>

    <h2>Program Chairs</h2><br />
    <div class="chairs">
        <div class="blk-3" style="text-align: center; margin-top: 20px;">
            <figure>
                <img class="round" src="<?php echo BASE_PATH; ?>/lib/img/people/Hrvoje_Benko.jpg" alt="Hrvoje Benko" />
                <figcaption>
                    <span style="font-size: 1.4em;">Hrvoje Benko</span><br />
                </figcaption>
            </figure>
        </div><div class="blk-3" style="text-align: center; margin-top: 20px;">
            <figure>
                <img class="round" src="<?php echo BASE_PATH; ?>/lib/img/people/daniel-wigdor.png" alt="Daniel Wigdor" />
                <figcaption>
                    <span style="font-size: 1.4em;">Daniel Wigdor</span><br />
                </figcaption>
            </figure>
        </div><div class="blk-3" style="text-align: center; margin-top: 20px;">
            <figure>
                <img class="round" src="<?php echo BASE_PATH; ?>/lib/img/people/photo.jpg" alt="Mira Dontcheva" />
                <figcaption>
                    <span style="font-size: 1.4em;">Mira Dontcheva</span><br />
                </figcaption>
            </figure>
        </div>
    </div>
</div>
